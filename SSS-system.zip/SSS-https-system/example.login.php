<?php
ob_start();
include 'SSS/SSS.php';
$SSS = new SSS();
$SSS->decodeBuffer();

echo "<html><head><title>Login form</title></head><body>";

if(isset($_SESSION['loged'])) {
    if(isset($_GET['logout'])) {
		unset($_SESSION['loged']);
		header("Location: ./example.login.php");
	}

	echo 'Wellcome, admin ! <a href="?logout">Logout</a>';
} else {
	if(isset($_SECURE['username']) && isset($_SECURE['password'])) {
		if($_SECURE['username'] == "admin" && $_SECURE['password'] == "admin") {
			$_SESSION['loged'] = true;
			header("Location: ./example.login.php");
		} else {
			echo 'Wrong username or password!<br/>';
		}
	}
	?>
	
	<h1>SSS Demo installation</h1>
	
	<hr />
	
	<form action="example.login.php" method="SECURE">
		<input type="text" name="username" placeholder="Username" value="admin" />
		<input type="text" name="password" placeholder="Password" value="admin" />
		<input type="submit" value="Login" />
    </form>
	
	<hr />
	
	<h2>EXAMPLE OF PROTECTED PAGE WITH SECURED PHP LOGIN FORM (method="SECURE")<br />THIS PAGE USING SCS (YOU CAN VIEW THE SOURCE CODE)</h2>

	<?php
}

echo "</body></html>";

$SSS->encodeBuffer();
?>
