<?php

include 'RSA/RSA.php';

Class SSS {
    public $opt = array(
            'path'           => 'SSS/', // SSS JS path
            'scriptsInclude' => true, 	// Enable including SSS javascript scripts. Set to false where you create JS request. Default: true
            'outputEncrypt'  => true, 	// Encrypt the output buffer with AES. Default: true
            'outputEdit'	 => true, 	// Enable editing the output buffer. Default: true
            'replaySecurity' => true, 	// Replay security status. Default: true
            'keysExperian'   => 43200, 	// Keys experian time in seconds. Default: 12 hours (43200)
            'enableCrawlers' => true,   // Enable crawlers
            'blockIframe'    => true,   // Block all iframes
            'blockProxy'     => true    // Block proxies
        );
	private $publickKey = false, $privateKey = false, $symetricKey = false;

    public $isCrawler = false, $isProxy = false;

    function SSS($options = false) {
        session_start();

        if($options) {
            $this->opt = array_merge($this->opt, $options);
        }

        $this->checker();
    }
	
    function checker()
    {
        if($this->opt['blockProxy']) {
            if($this->isProxy()) {
                ob_clean();
                echo "Proxy is not allowed!";
                exit;
            }
        }

        if($this->opt['blockIframe']) {
            header("X-FRAME-OPTIONS: DENY");
        } else {
            header_remove("X-FRAME-OPTIONS"); 
        }

        if($this->opt['enableCrawlers']) {
            $this->isCrawler = $this->detectCrawler($_SERVER['HTTP_USER_AGENT']);

            if($this->isCrawler) {
                $this->opt['outputEdit'] = false;
            }
        } else {
            $this->isCrawler = false;
            $this->opt['outputEdit'] = true;
        }
    }

    function isProxy()
    {
        $proxy_headers = array(
            'HTTP_X_REAL_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_PROXY_ID',
            'HTTP_VIA',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_FORWARDED',
            'HTTP_CLIENT_IP',
            'HTTP_FORWARDED_FOR_IP',
            'VIA',
            'X_FORWARDED_FOR',
            'FORWARDED_FOR',
            'X_FORWARDED FORWARDED',
            'CLIENT_IP',
            'FORWARDED_FOR_IP',
            'HTTP_PROXY_CONNECTION',
            'HTTP_XROXY_CONNECTION'
        );

        foreach($proxy_headers as $x) {
            if (isset($_SERVER[$x])) return true;
        }

        return false;
    }

    function detectCrawler($USER_AGENT)
    {
        $crawlers = array(
                'Bloglines subscriber',
                'Dumbot',
                'Sosoimagespider',
                'QihooBot',
                'FAST-WebCrawler',
                'LinkWalker',
                'msnbot',
                'ASPSeek',
                'WebAlta Crawler',
                'Lycos',
                'FeedFetcher-Google',
                'Yahoo',
                'YoudaoBot',
                'AdsBot-Google',
                'Googlebot',
                'Scooter',
                'Gigabot',
                'Charlotte',
                'eStyle',
                'AcioRobot',
                'GeonaBot',
                'msnbot-media',
                'Baidu',
                'CocoCrawler',
                'Google',
                'Charlotte t',
                'Yahoo! Slurp China',
                'Sogou web spider',
                'YodaoBot',
                'MSRBOT',
                'AbachoBOT',
                'Sogou head spider',
                'AltaVista',
                'IDBot',
                'Sosospider',
                'Yahoo! Slurp',
                'Java VM',
                'DotBot',
                'LiteFinder',
                'Yeti',
                'Rambler',
                'Scrubby',
                'Baiduspider',
                'accoona'
            );

        foreach($crawlers as $crawler) {
            if (strpos(strtolower($USER_AGENT), trim($crawler)) !== false) {
                return true;
            }
        }

        return false;
    }

	private function loadKeys()
	{
        $date = file_get_contents(dirname(__FILE__)."/keys/date.experian");

        if((int)$date < (time() - $this->opt['keysExperian'])) {
            $this->renewKeys();
        } else {
            $this->publickKey = file_get_contents(dirname(__FILE__)."/keys/public.key");
            $this->privateKey = file_get_contents(dirname(__FILE__)."/keys/private.key");
        }
	}
	
	private function renewKeys()
	{
		$rsa = new Crypt_RSA();
        $keys = $rsa->createKey();
		file_put_contents(dirname(__FILE__)."/keys/private.key", $keys["privatekey"]);
		file_put_contents(dirname(__FILE__)."/keys/public.key", $keys["publickey"]);
        file_put_contents(dirname(__FILE__)."/keys/date.experian", time());
        $this->publickKey = $keys["publickey"];
        $this->privateKey = $keys["privatekey"];
	}
	
    function decodeBuffer() {
        if($this->opt["enableCrawlers"] && $this->isCrawler) {
            return;
        }

        if(!isset($_SESSION['symetricKey'])) {
			$this->loadKeys();
            if(isset($_POST['symetricKey'])) {
                header('Content-type: application/json');
                $key = $this->RSA_decrypt($_POST['symetricKey'], $this->privateKey);
                if(strlen($key) != 50) {
                    ob_clean();
                    die("[ERR_KEY_SEND]");
                }
                $_SESSION['symetricKey'] = $key;
                $_SESSION['lastDate'] = 1;
                $this->opt['scriptsInclude'] = false;
                $this->symetricKey = $key;
            } else {
                echo $this->loadJS("<script>SSS.sendSymetricKey('".rawUrlEncode($this->publickKey)."');</script>");
                exit;
            }
        } else {
            $this->symetricKey = $_SESSION['symetricKey'];
            if($this->opt['replaySecurity']) {
            	$this->replaySecurity();
            }
        }

        if(isset($_POST['secureData'])) {
            $data = trim($_POST['secureData']);

            if($data != null) {
                $data = $this->decode($data);

                unset($_POST['secureData']);

                foreach (explode("&", $data) as $header) {
                    $info = explode("=", $header);

                    if(count($info) == 2) {
                       $GLOBALS['_SECURE'][$info[0]] = rawurldecode($info[1]);
                    }
                }
            }
        }
    }

    function replayChecker() {
        if(isset($_POST['replayChecker'])) {
            echo '[ERR_REPLAY_CHECKER]';
        } else {
            echo $this->loadJS('<script>SSS.replayChecker();</script>');
        }
        exit;
    }

    function decode($data) {
        return $this->cryptoJsAesDecrypt($this->symetricKey, $data);
    }

    function encode($data) {
        return $this->cryptoJsAesEncrypt($this->symetricKey, $data);
    }

    function replaySecurity() {
        $lastDate = $_SESSION['lastDate'];

        if(isset($_POST['replayChecker'])) {
            header('Content-type: application/json');
        }

        if(isset($_COOKIE['lastDate'])) {
            $newDate = $this->decode($_COOKIE['lastDate']);
              
            if($newDate > $lastDate && is_numeric($newDate) && strlen($newDate) == 13) {
                $_SESSION['lastDate'] = $newDate;

                return;
            }
        }

        $this->replayChecker();
    }

    function RSA_decrypt($text, $key) {
        $rsa = new Crypt_RSA();
        $rsa->setEncryptionMode(CRYPT_RSA_ENCRYPTION_PKCS1);
        $rsa->loadKey($key);
        return $rsa->decrypt(base64_decode($text));
    }

    function hex2bin($hexstr)  { 
        $n = strlen($hexstr); 
        $sbin="";   
        $i=0; 
        while($i<$n) 
        {       
            $a =substr($hexstr,$i,2);           
            $c = pack("H*",$a); 
            if ($i==0){$sbin=$c;} 
            else {$sbin.=$c;} 
            $i+=2; 
        } 
        return $sbin;
    } 

    function cryptoJsAesDecrypt($passphrase, $jsonString) {
        $jsondata = json_decode($jsonString, true);
        $salt = $this->hex2bin($jsondata["s"]);
        $ct = base64_decode($jsondata["ct"]);
        $iv  = $this->hex2bin($jsondata["iv"]);
        $concatedPassphrase = $passphrase.$salt;
        $md5 = array();
        $md5[0] = md5($concatedPassphrase, true);
        $result = $md5[0];
        for ($i = 1; $i < 3; $i++) {
            $md5[$i] = md5($md5[$i - 1].$concatedPassphrase, true);
            $result .= $md5[$i];
        }
        $key = substr($result, 0, 32);
        $data = openssl_decrypt($ct, 'aes-256-cbc', $key, true, $iv);
        return json_decode($data, true);
    }

    function cryptoJsAesEncrypt($passphrase, $value) {
        $salt = openssl_random_pseudo_bytes(8);
        $salted = '';
        $dx = '';
        while (strlen($salted) < 48) {
            $dx = md5($dx.$passphrase.$salt, true);
            $salted .= $dx;
        }
        $key = substr($salted, 0, 32);
        $iv  = substr($salted, 32,16);
        $encrypted_data = openssl_encrypt($value, 'aes-256-cbc', $key, true, $iv);
        $data = array("ct" => base64_encode($encrypted_data), "iv" => bin2hex($iv), "s" => bin2hex($salt));
        return json_encode($data);
    }

    function encodeBuffer() {
        $this->checker();

    	if(!$this->opt['outputEdit']) {
    		return;
    	}
    	
        $out = ob_get_clean();

        ob_start();

        $source = array();

    	if($this->opt['outputEncrypt']) {
            $source['encrypted'] = $this->encode($out);
    	} else {
            $source['raw'] = $out;
        }

        $output = json_encode($source);

        if($this->opt['scriptsInclude'] && !isset($_POST['replayChecker'])) {
            echo $this->loadJS(($this->opt['outputEncrypt'] ? "<script>var source = ".$output.";</script>" : $source['raw'])."<script>SSS.finishScripts();</script>");
        } else {
        	echo $output;
        }

        ob_end_flush();
    }

    function loadJS($script = null) {
        return '<!DOCTYPE HTML><script src="'.$this->opt['path'].'JS/aes.js"></script><script src="'.$this->opt['path'].'JS/jquery.min.js"></script><script src="'.$this->opt['path'].'JS/jsencrypt.js"></script><script src="'.$this->opt['path'].'JS/SSS.js"></script>'.$script;
    }
}

?>
