/*
SSS
Dotcomsecurity
(c) 2016 by Adrian Janotta. All rights reserved.
*/



var SCS = {
	symetricKey: localStorage.getItem('symetricKey'),
 	randomString: function(length) {
		var string = "";
		var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		for(var i = 0; i < length; i++) {
			string += possible.charAt(Math.floor(Math.random() * possible.length));
		}
		return string;
	},
    RSAencode: function(text, publicKey) {
		var crypt = new JSEncrypt();
    	crypt.setPublicKey(publicKey);
    	return crypt.encrypt(text);
	},
	dellCookie: function(name) {
		document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
	},
    sendSymetricKey: function(publicKey) {
		publicKey = decodeURIComponent(publicKey);
		var sKey = this.randomString(50);

		var context = this;

		$.post( "", { symetricKey: this.RSAencode(sKey, publicKey) })
  		.done(function( response ) {
    		if(response != "[ERR_KEY_SEND]") {
    			context.symetricKey = sKey;
    			context.lastDateUpdate();
    			localStorage.setItem("symetricKey", context.symetricKey);
    			context.pageDecode(response);
    			context.finishScripts();
    		} else {
    			context.dellCookie("PHPSESSID");
				context.dellCookie("lastDate");
				location.reload();
    		}
  		});
	},
    CryptoJSAesJson: {
		stringify: function (cipherParams) {
			var j = {ct: cipherParams.ciphertext.toString(CryptoJS.enc.Base64)};
			if (cipherParams.iv) j.iv = cipherParams.iv.toString();
			if (cipherParams.salt) j.s = cipherParams.salt.toString();
			return JSON.stringify(j);
		},
		parse: function (jsonStr) {
			var j = JSON.parse(jsonStr);
			var cipherParams = CryptoJS.lib.CipherParams.create({ciphertext: CryptoJS.enc.Base64.parse(j.ct)});
			if (j.iv) cipherParams.iv = CryptoJS.enc.Hex.parse(j.iv)
				if (j.s) cipherParams.salt = CryptoJS.enc.Hex.parse(j.s)
					return cipherParams;
			}
		},
	createCookie: function(name, value) {
    	var date = new Date();
    	date.setTime(date.getTime() + (100000000));
    	var expires = "; expires=" + date.toGMTString();
    	document.cookie = encodeURIComponent(name) + "=" + encodeURIComponent(value) + expires + "; path=/";
	},
	isValidBuffer: function(b) {
  		return b.hasOwnProperty("raw") || b.hasOwnProperty("encrypted"); 
	},
 	lastDateUpdate: function() {
		if(this.symetricKey != null) {
			var date = Date.now();
			var encode = this.encode(date);
			this.createCookie("lastDate", encode);
		}
	},
	encode: function(buffer, isArr) {
		isArr = typeof isArr !== 'undefined' ? isArr : false;

		if(isArr) {
			var serialize = "";

			$.each( buffer, function( key, value ){
				if(serialize != "") {
					serialize += "&";
				}
				serialize += encodeURI(key) + "=" + encodeURI(value);
			});

			buffer = serialize;
		}

		return CryptoJS.AES.encrypt(JSON.stringify(buffer), this.symetricKey, {format: this.CryptoJSAesJson}).toString();
	},
  	decode: function(buffer) {
  		if (!this.isValidBuffer(buffer)) {
  			buffer = JSON.parse(buffer);
  		}
  		if(buffer.hasOwnProperty("raw")) {
  			return buffer.raw;
  		} else {
  			return CryptoJS.AES.decrypt(buffer.encrypted, this.symetricKey, {format: this.CryptoJSAesJson}).toString(CryptoJS.enc.Utf8);
  		}
	},
 	pageDecode: function(buffer) {
 		$("head").html("");
 		document.open();
		document.write(this.decode(buffer));
		document.close();
	},
 	formConvert: function(form) {
		var serialize = "";

		$(form).find("input[name]:not([type='file']):not([raw])").each(function() {
			if(serialize != "") {
				serialize += "&";
			}

			serialize += encodeURI($(this).attr('name')) + "=" + encodeURI($(this).val());

			$(this).removeAttr("name");
		});

		var data = this.encode(serialize);

		$(form).append("<input type='hidden' name='secureData' value='" + data + "' />");

		$(form).attr("method", "POST");
	},
	replayChecker: function() {
		var context = this;

		$.ajax({
		  method: "POST",
		  url: "",
		  data: { replayChecker: true },
		  complete: function(e, xhr, settings){
	            var response = e.responseText;

	            if(response.indexOf("[ERR_REPLAY_CHECKER]") == -1) {
	            	context.lastDateUpdate();
	    			context.pageDecode(response);
	    			context.finishScripts();
	    		} else {
	    			context.dellCookie("PHPSESSID");
					context.dellCookie("lastDate");
					console.log(document.cookie);
					// location.reload();
	    		}
		   }
		});
	},
 	finishScripts: function() {
		if (typeof source !== 'undefined') {
			this.pageDecode(source);
		}

		var context = this;
		$("form[method='SECURE']").submit(function( event ) {
			context.formConvert(this);
		});
	}
}

SCS.lastDateUpdate();

window.setInterval(function(){ SCS.lastDateUpdate(); }, 1000);
