<?php
ob_start();
include 'SCS/SCS.php';
$SCS = new SCS();
$SCS->decodeBuffer();

echo "<html><head><title>Login form with json</title></head><body>";

if(isset($_SESSION['loged'])) {
    if(isset($_GET['logout'])) {
		unset($_SESSION['loged']);
		header("Location: ./example.json.login.php");
	}

	echo 'Wellcome, admin ! <a href="?logout">Logout</a>';
} else {
	if(isset($_SECURE['username']) && isset($_SECURE['password'])) {
		$SCS->opt['scriptsInclude'] = false; // Disable showing scripts
		$msg = array('status' => false, 'message' => null);

		if($_SECURE['username'] == "admin" && $_SECURE['password'] == "admin") {
			$_SESSION['loged'] = true;
			$msg['status'] = true;
		} else {
			$msg['message'] = 'Wrong username or password!';
		}

		ob_clean(); // CLear html tags
		echo json_encode($msg);
		exit;
	}
?>

    <h1>SCS Demo</h1>
	
	<hr />
	
	<form id="login-form">
		<div id="message"></div>
		<input type="text" name="username" placeholder="Username" value="admin" />
		<input type="text" name="password" placeholder="Password" value="admin" />
		<input type="submit" value="Login" />
    </form>
	
	<hr />
	
	<h2>EXAMPLE OF PROTECTED PAGE WITH SECURED PHP LOGIN FORM (method="SECURE")<br />THIS PAGE USING SCS (YOU CAN VIEW THE SOURCE CODE)</h2>
	
    <script>
	$( "#login-form" ).submit(function( event ) {
		var username = $(this).find("input[name='username']").val();
		var password = $(this).find("input[name='password']").val();

		$(this).find("#message").text("Loading...");

		var context = this;

		$.post( "example.json.login.php", { secureData: SCS.encode({ username: username, password: password }, true) })
  		.done(function( response ) {
  			var parse = JSON.parse(response);
    		
    		if(parse.status) {
    			location.reload();
    		} else {
    			$(context).find("#message").text(parse.message);
    		}
  		});

  		return false;
	});
    </script>
<?php
}

echo "</body></html>";

$SCS->encodeBuffer();
?>